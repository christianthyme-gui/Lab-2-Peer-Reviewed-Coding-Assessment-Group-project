//student:Christian Thyme
//Date: Ocotober 28,2026
import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.Color;



//Main: calls the shopping list, with filtered pane and menubar buttons
//filtered pane allows the user to type into bottom text and it shows the list present that is has to the side.
// menubar: allows the user to press buttons for additonal functionality
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            
            JFrame jFrame = new JFrame("Shopping List Application");
            ShoppingList slist = new ShoppingList("Shopping List", 
            "Milk", "Eggs", "Cheese", "Bread", "Coffee"
            );

            jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jFrame.setLayout(new BorderLayout());
            // Calls the crratescrollpane for the main text promtp
            jFrame.add(slist.createScrollPane(), BorderLayout.CENTER);
            
            // makes the header's menu bar to allow the user to influcence the list model.
            jFrame.setJMenuBar(createMenuBar(jFrame, slist));
            
            jFrame.setSize(800, 700);
            jFrame.setLocationRelativeTo(null);
            jFrame.setVisible(true);
        });
    }

        // is used for the header menu bar
        //createmenuBar: makes a menu bar with buttons the user can press
        // file: allows the user to affect the entire window. Close: closes the window, new: clears all the text present
        //
        private static JMenuBar createMenuBar(JFrame frame, ShoppingList shoppingList) {
        JMenuBar menuBar = new JMenuBar();
        
        menuBar.setBackground(Color.BLACK);
        menuBar.setBorder(BorderFactory.createLineBorder(Color.RED, 2));


        JMenu fileMenu = new JMenu("File");
        JMenu editMenu = new JMenu("Edit");

        // button actions for file menu
        // sends the frame to shopping list method closewindow
        JMenuItem closeItem = new JMenuItem("Close");
        closeItem.addActionListener(event -> shoppingList.closeWindow(frame));

            //newList: clears all the text found in the main text area model given from shopping list
        JMenuItem newList = new JMenuItem("New");
        newList.addActionListener(event -> shoppingList.makeNewList());

            // a list of commands for the edit menu
        //clear selection not working, needs to remove the line selected.
        // fixed: made a public method called clear selection
        // than the method connects to removeselcted, which clears the line the user clicked on
        // if the user dosen't click on anything, than the method dosen't do anything,

        // clearSelectedItem: removes the line the user has selected with a red boundary around the cell 
        JMenuItem clearSelectedItem = new JMenuItem("Clear selection");
        clearSelectedItem.addActionListener(event -> shoppingList.clearSelection());

        // JMenuItem: button menu prompt for removing purchased items that are striked through
        JMenuItem clearPurchasesItem = new JMenuItem("Clear Purchases");
        clearPurchasesItem.addActionListener(event -> shoppingList.clearPurchases());

        // addNewListItem: Menu prompt appears asking the user to type a value, once done if it's not the same 
        // it'll be added to the dictioonary list for display
        JMenuItem addNewListItem = new JMenuItem("Add Item");
        addNewListItem.addActionListener(event -> shoppingList.addNewItem());
        // button menu prompt allowing the user to text a value by the first letter than print it out
        // into the terminal
        // removed reload text filter, as it wasn't needed with the new filtermodel

        // method addtions for file menu

        // closeItem: closes the window
        fileMenu.add(closeItem);
        fileMenu.add(newList);

        // method additions for edit menue
        editMenu.add(clearSelectedItem);
        editMenu.add(clearPurchasesItem);
        editMenu.add(addNewListItem);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        
        // returns the menubar with all it's functionality
        // from the button methods added.
        return menuBar;
    }
    
}


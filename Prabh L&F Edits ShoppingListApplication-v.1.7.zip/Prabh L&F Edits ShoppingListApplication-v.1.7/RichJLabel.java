import java.awt.*;
import javax.swing.*;



public class RichJLabel extends JLabel {

    public RichJLabel(String text) {
        super(text);
        setHorizontalAlignment(SwingConstants.CENTER); // Renders it in a center position in the layout
    }

    @Override     // The textbook asks us to override the "paintComponent()" method and NOT paint().
    protected void paintComponent(Graphics g) {
        
        FontMetrics fm = g.getFontMetrics(getFont());
        int x = (getWidth() - fm.stringWidth(getText())) / 2;
        int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();

        // Sets the color of the shadow (can be any colour, [colour] to stand out with the a different colour background)
        g.setColor(Color.BLACK);
        g.drawString(getText(), x + 4, y + 4);      // Based on the technique shown in Hack 2, slightly modified using fixed offsets
        
        // The main text
        g.setColor(getForeground());
        g.drawString(getText(), x, y);
    }
}
import java.util.Dictionary;
import java.util.Hashtable;
import javax.swing.DefaultListModel;

/*
 * Author: Prof Autorino
 * 
 * ShoppingListModel.java (WIP)
 * Creates a custom DefaultListModel for our ShoppingListApplication.
 * 
 * https://docs.oracle.com/javase/8/docs/api/javax/swing/DefaultListModel.html
 * 
 * TODO: Complete class signature
 */ 

//for the model, i think overcomplicated the idea by adding renderer and methods
// for this model, it replaces the orignal default list model methods.
public class ShoppingListModel extends DefaultListModel<String> {
        // TODO: Use Dictionary of Labels and Booleans instead of ArrayList.
        // learned about maps that allows 
        // used dictionaries as that what the assignment calls for
        // use the put method command to add both a key and value
        //String is the key, Boolean is the value
        //https://www.baeldung.com/java-hashmap-vs-dictionary
        private final Dictionary<String,Boolean> purchasedItems = new Hashtable<>();
        //private List<Boolean> purchasedItems = new ArrayList<>();

        // ShoppingListModel(List<Boolean> purchasedItemList) {
        //     this.purchasedItems = purchasedItemList;

        //     // TODO: Complete constructor

        // }
        // TODO: Complete ShoppingListModel
        // adds the based methods that are used from the shopping list
        /* 
        AddModelItem: adds a item, and sets it false
        ClearModelItems: Clears the model used
        removeModelItemAt(int index): removes the index that stores both the key and value found in the dictionary
        
        */

        public void AddModelItem(String Item){
            purchasedItems.put(Item,false);
        }

        public void clearModelItems() {
            super.clear();
            //purchasedItems.clear();
            //purchasedItems.clear();
        
        }

        public boolean isPurchasedAtModel(int index){
            return purchasedItems.get(getElementAt(index));
        }

        public void removeModelItemAt(int index){
            purchasedItems.remove(index);
        }

        

        
}

student: christian Thyme
Date: October 25,2026
version: 1.0-no ai

notice: aung previously used ai for the completion of the assignment.However, i used no ai. 
my current goal: is make the model, as well as inciting what i can do to make it more human made.

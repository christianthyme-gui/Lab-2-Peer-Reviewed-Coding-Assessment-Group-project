Student: Christian Thyme
Date: Ocotober 9,2026
Ai notice: None was used for the creation of the code.

How to run:

javac *.java
java Main

self graded rubric:
1.Added comments explaining the functions on the ShoppingList class, and main
2. their are multiple jmenu bars based on 
3.Filter components: there are two, 
one based on the swing hack 13 which allows the user to type values that automattically filter out the response
two was made separatly to allow the user to print out all the list elements starting with one letter that matches

The requirements of the assignment (see above) 40pts
Additionally, 15/50 points will be rewarded for completing the assignment requirements without artificial intelligence.
Failure to complete the tasks outlined by the assignment description above without relying on a LLM will deduct 15 points from your grade. 
Regardless of this requirement, you are still required to report any and all AI usage.
Failure to reference AI usage may result in harsher point deductions.40/40- no ai was used for the creation of the code.
Correct software architecture/paradigm and MVC design. Did you separate your code into components and import them into a main driver class? 20pts/20: 
Well documented code; comments, README.md and a robots.txt file that explains AI usage (including prompts, GenAI, etc.) 20pts/20 comments made to explain each of the methods 
// as well as how they are used
Your program included at least two of the "hacks" from the textbook, Swing Hacks: Tips & Tools for Building Killer GUIs by Joshua Marinacci and Chris Adamson. 10pts

Swing hacks used
swing hack 13- used for the incomplete filter structure
swing hack 3- adds a image border over the filter structure
Swing hack 2- Rich j label that changes the text for the ShoppingList header

Sources that helped with coding:

https://stackoverflow.com/questions/14098032/add-string-to-string-array
https://www.geeksforgeeks.org/java/how-to-add-an-element-to-an-array-in-java/
https://www.geeksforgeeks.org/java/how-to-convert-a-string-to-a-character-in-java/
https://www.youtube.com/watch?v=HbxccWk4VuQ
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.TextAttribute;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.Point;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.AbstractAction;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;

/**
 * 
 * ShoppingList
 * A string-based shopping list component with toggleable purchased items and a title header. 
 */
public class betashop extends JList<String> {
    private final List<Boolean> purchasedItems = new ArrayList<>();
    private final DefaultListModel<String> itemModel;
    private final JLabel headerLabel;

    /**
    *
    * Creates a shopping list with the given title and initial items
    *  
    * @param title text shown in the list's column header.
    * @param initialItems items to displau initially; may be blank 
    * 
    * new ShoppingList("Title", "Milk", "Eggs", "Cheese")
    */
    public betashop(String title, String... initialItems) {
        super(new DefaultListModel<>());
        // TODO: Replace DefaultListModel with ShoppingListModel
        this.itemModel = (DefaultListModel<String>) getModel();
        this.headerLabel = new JLabel(title);
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setCellRenderer(new ShoppingListItemRenderer());
        for (String item : initialItems) {
            addItem(item);
        }
        addMouseListener(new MouseAdapter() {
            @Override 
            public void mouseClicked(MouseEvent mouseEvent) {
                if (mouseEvent.getButton() == MouseEvent.BUTTON1) {
                    toggleItemAt(mouseEvent.getPoint());
                }
            }
        });
        getActionMap().put("togglePurchased", new AbstractAction() {
           @Override
           public void actionPerformed(ActionEvent event) {
              // toggle selected item as purchased
              toggleSelectedItem();
           } 
        });
    }

    /**
     * Creates a scroll pane with this list and its title header.
     * 
     * @return JScrollPane scrollPane
     */
    public JScrollPane createScrollPane() {
        JScrollPane scrollPane = new JScrollPane(this);
        JPanel header = new JPanel(new BorderLayout());
        header.add(headerLabel, BorderLayout.CENTER);
        scrollPane.setColumnHeaderView(header);
        return scrollPane;
    }

    public void addItem(String item) {
        itemModel.addElement(item);
        purchasedItems.add(false);
    }

    public void clearItems() {
        itemModel.clear();
        purchasedItems.clear();
    }

    public void removeSelectedItem() {
        int index = getSelectedIndex();
        if (index >= 0) {
            itemModel.remove(index);
            purchasedItems.remove(index);
        }
    }

    public void removePurchasedItems() {
        for (int index = purchasedItems.size() - 1; index >= 0; index--) {
            if (purchasedItems.get(index)) {
                itemModel.remove(index);
                purchasedItems.remove(index);
            }
        }
    }

    /**
     * Returns the current item text in display order.
     * 
     * @return List<String> items
     */
    public List<String> getItems() {
        List<String> items = new ArrayList<>(itemModel.size());
        for (int index = 0; index < itemModel.size(); index++) {
            items.add(itemModel.get(index));
        }
        return items;
    } 

    private void toggleSelectedItem() {
        int index = getSelectedIndex();
        if (index >= 0) {
            togglePurchased(index);
        }
    }

    private void togglePurchased(int index) {
        purchasedItems.set(index, !purchasedItems.get(index));
        repaint(getCellBounds(index, index));
    }

    private void toggleItemAt(Point point) {
        int index = locationToIndex(point);
        if (index >= 0 && getCellBounds(index, index).contains(point)) {
            setSelectedIndex(index);
            togglePurchased(index);
        }
    }

    /**
    * ShoppingListItemRenderer overrides the default rendering behavior of list items so that
    * the app can modify text attributes of purchased rows to reflect the purchasedItems list.
    * We must use a HashMap to modify the font of a component in a ListCellRenderer.
    * 
    */
    private final class ShoppingListItemRenderer extends DefaultListCellRenderer {
        @Override 
        public Component getListCellRendererComponent(JList<?> list,
                                              Object value,
                                              int index,
                                              boolean isSelected,
                                              boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            setText(value == null ? "" : value.toString());
            if (index >= 0 && index < purchasedItems.size() && purchasedItems.get(index)) {
                Map<TextAttribute, Object> attributes = new HashMap<>();
                attributes.put(TextAttribute.STRIKETHROUGH, TextAttribute.STRIKETHROUGH_ON);
                Font font = getFont();
                setFont(font.deriveFont(attributes));
            }
            return this;                                 
        }
    }
}
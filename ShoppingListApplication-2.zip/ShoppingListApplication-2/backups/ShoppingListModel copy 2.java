// import java.util.ArrayList;
// import java.util.List;
// import javax.swing.DefaultListModel;

// /*
//  * Author: Prof Autorino
//  * 
//  * ShoppingListModel.java (WIP)
//  * Creates a custom DefaultListModel for our ShoppingListApplication.
//  * 
//  * https://docs.oracle.com/javase/8/docs/api/javax/swing/DefaultListModel.html
//  * 
//  * TODO: Complete class signature
//  */ 

// public class ShoppingListModel extends DefaultListModel<String> {
//         // TODO: Use Dictionary of Labels and Booleans instead of ArrayList.
//         private List<Boolean> purchasedItems = new ArrayList<>();

//         ShoppingListModel(List<Boolean> purchasedItemList) {
//             this.purchasedItems = purchasedItemList;

//             // TODO: Complete constructor

//         }

//         // TODO: Complete ShoppingListModel

        
// }
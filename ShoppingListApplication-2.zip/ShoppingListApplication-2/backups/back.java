// import java.util.ArrayList;
// import java.util.List;
// import java.util.Map;

// import javax.swing.DefaultListCellRenderer;
// import javax.swing.DefaultListModel;
// import javax.swing.JLabel;
// import javax.swing.JList;

// import java.util.Dictionary;
// import java.util.HashMap;
// import java.util.Hashtable;

// // /*
// //  * Author: Prof Autorino
// //  * 
// //  * ShoppingListModel.java (WIP)
// //  * Creates a custom DefaultListModel for our ShoppingListApplication.
// //  * 
// //  * https://docs.oracle.com/javase/8/docs/api/javax/swing/DefaultListModel.html
// //  * 
// //  * TODO: Complete class signature
// //  */ 

// public class back extends DefaultListModel<String> {
//         // TODO: Use Dictionary of Labels and Booleans instead of ArrayList.
//         // the jlabel is the key
//         // the the jlabel has a boolean as a value
//         private Dictionary<JLabel,Boolean> purchasedItems = new Hashtable<>();
//         private final DefaultListModel<String> itemModel;
//         //private List<Boolean> purchasedItems = new ArrayList<>();
            
//         // taken from shopping list
//         ShoppingListModel(List <String> purchasedItemList,String... initialItems) {
//             //this.purchasedItems = purchasedItemList;
            

//             // copied from shopping list
//             // is added to 
//             for(String item: purchasedItemList){
//                 addModelItem(item);
//             }

           

//             // TODO: Complete constructor

//         }

        

//         // TODO: Complete ShoppingListModel

//         //AddItem: uses the parameter to add a string directly to the model
//         //https://www.geeksforgeeks.org/java/dictionary-put-method-in-java-with-examples/
//         public void addModelItem(String item) {
//             JLabel tempLabel = new JLabel(item);
//             purchasedItems.put(tempLabel,false);
//             //purchasedItems.addElement(item,false);
//             //purchasedItems.add(false);
//         }

        

        
// }
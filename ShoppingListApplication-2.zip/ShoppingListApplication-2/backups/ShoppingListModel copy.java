// import java.util.ArrayList;
// import java.util.List;
// import javax.swing.DefaultListModel;

// /*Ocotober 22,2026
// student: Christian Thyme
// Remodel skeleton,
// */
// //@SuppressWarnings("rawtypes")
// public class ShoppingListModel extends DefaultListModel<String>{
//     //Todo: Use dictionary of labels and booleans instead of arrayList.
//     private List<Boolean> purchasedItems = new ArrayList<>();

//     ShoppingListModel(List<Boolean> purchasedItemList){
//         this.purchasedItems = purchasedItemList;

//         //Todo: Complelte constructor, which acess the list and changes it 


//     }
    
    
    
// } //Todo: ShoppingList Model

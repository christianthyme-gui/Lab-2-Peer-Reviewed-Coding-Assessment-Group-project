// is from swing hack 13-filter j

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class FilteredJlistTester {

    public static void main (String[] args) {

        String[] listItems = {

            "Chris", "Joshua", "Daniel", "Michael",

            "Don", "Kimi", "Kelly", "Keagan"

        };

        JFrame frame = new JFrame ("FilteredJList");

        frame.getContentPane().setLayout (new BorderLayout( ));

        // populate list

        FilteredJList list = new FilteredJList( );

        for (int i=0; i<listItems.length; i++)

            list.addItem (listItems[i]);

            // add to gui

            JScrollPane pane = new JScrollPane (list,

                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,

                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);


                frame.getContentPane( ).add (pane, BorderLayout.CENTER);

                frame.getContentPane().add (list.getFilterField( ),

                BorderLayout.NORTH);

                frame.pack( );

                frame.setVisible(true);

            }
    

        }
    

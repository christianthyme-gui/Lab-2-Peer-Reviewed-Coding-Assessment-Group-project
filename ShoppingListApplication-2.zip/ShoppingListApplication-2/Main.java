//student:Christian Thyme
//Date:october 22,2026
import java.awt.BorderLayout;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

//Main: calls the shopping list, with filtered pane and menubar buttons
//filtered pane allows the user to type into bottom text and it shows the list present that is has to the side.
// menubar: allows the user to press buttons for additonal functionality
public class Main {
    // act as global variables for the filteredjlist methods
    public static final JPanel jPanel = new JPanel();
    public static FilteredJList list = new FilteredJList( );
   
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            
            JFrame jFrame = new JFrame("Shopping List Application");
            ShoppingList slist = new ShoppingList("ShoppingList", 
            "Milk", "Eggs", "Cheese", "Bread", "Coffee"
            );
            //FilteredJList FillerList = new FilteredJList( );
            //jFrame.add(createFilterPanel(jFrame,slist), BorderLayout.CENTER);
            //createFilterBar(jFrame, slist);


            jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jFrame.setLayout(new BorderLayout());
            // Calls the crratescrollpane for the main text promtp
            jFrame.add(slist.createScrollPane(), BorderLayout.CENTER);

            // makes the filtered bar section on the bottom
            jFrame.add(createFilterBar(slist),BorderLayout.SOUTH);
            
            // makes the header's menu bar to allow the user to influcence the list model.
            jFrame.setJMenuBar(createMenuBar(jFrame, slist));
            
            jFrame.setSize(500, 500);
            jFrame.setLocationRelativeTo(null);
            jFrame.setVisible(true);
        });
    }

    // refil: clears the list, and than reapply the values found in the shopping list class model
    private static void refil(ShoppingList shoppingList){
        // uses a custom method to remove all the elements from the list
        // before using it by adding all the values from the user shopping list
        list.clear();
        

        for (String item : shoppingList.getItems()) {
            
            list.addItem(item);
            //list.remove(shoppingList);

        }
        //list = newlisttemporary;
    }

    
    // pseudo code:
    //make a method that updates with new informations.
    // it uses a parameter
    // returns a list

    // method used to create filterbar
    // uses swing hack 13
    // createfilterbar: makes a seperate pane that return as a jpanel
    // uses the filtered list variable to get it methods
    // uses the shopping list parameter to fill out the filtered list the first time.
    private static JPanel createFilterBar(ShoppingList shoppingList){

        //String[] temp = shoppingList.getItems().toArray(new String[0]);

            // 
            JScrollPane pane = new JScrollPane(list,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER
            );
            // image border is from swing hack 3
            // adds a border around the 
            ImageBorder image_border = new ImageBorder(
                new ImageIcon("images/BorderFrames/upper_left.png").getImage( ),
                new ImageIcon("images/BorderFrames/upper.png").getImage( ),
                new ImageIcon("images/BorderFrames/upper_right.png").getImage( ),
                new ImageIcon("images/BorderFrames/left_center.png").getImage( ),
                new ImageIcon("images/BorderFrames/right_center.png").getImage( ),
                new ImageIcon("images/BorderFrames/bottom_left.png").getImage( ),
                new ImageIcon("images/BorderFrames/bottom_center.png").getImage( ),
                new ImageIcon("images/BorderFrames/bottom_right.png").getImage( )
                );
                jPanel.setBorder(image_border);

                for (String item : shoppingList.getItems()) {
                    list.addItem(item);

                    //frame.getContentPane().add(pane,BorderLayout.SOUTH);
                    jPanel.add(pane,BorderLayout.SOUTH);

                    //frame.getContentPane().add (list.getFilterField(), BorderLayout.SOUTH);
                    jPanel.add(list.getFilterField(), BorderLayout.SOUTH);

                }
            return jPanel;
        }
        
        // is used for the header menu bar
        //createmenuBar: makes a menu bar with buttons the user can press
        // file: allows the user to affect the entire window. Close: closes the window, new: clears all the text present
        //
        private static JMenuBar createMenuBar(JFrame frame, ShoppingList shoppingList) {
        JMenuBar menuBar = new JMenuBar();
        
        JMenu fileMenu = new JMenu("File");
        JMenu editMenu = new JMenu("Edit");

        // button actions for file menu
        // close works, using window event
        JMenuItem closeItem = new JMenuItem("Close");
        closeItem.addActionListener(event -> frame.dispatchEvent(new 
            WindowEvent(frame, WindowEvent.WINDOW_CLOSING)));

            //newList: clears all the text found in the main text area model given from shopping list
        JMenuItem newList = new JMenuItem("New");
        newList.addActionListener(event -> shoppingList.makeNewList());

            // a list of commands for the edit menu
        //clear selection not working, needs to remove the line selected.
        // fixed: made a public method called clear selection
        // than the method connects to removeselcted, which clears the line the user clicked on
        // if the user dosen't click on anything, than the method dosen't do anything,

        // changed variables to be more clear on what they don
        JMenuItem clearSelectedItem = new JMenuItem("Clear selection");
        clearSelectedItem.addActionListener(event -> shoppingList.clearSelection());

        // button menu prompt for removing purchased items.
        JMenuItem clearPurchasesItem = new JMenuItem("Clear Purchases");
        clearPurchasesItem.addActionListener(event -> shoppingList.clearPurchases());

        // button menu prompt for removing purchased items.
        JMenuItem addNewListItem = new JMenuItem("Add Item");
        addNewListItem.addActionListener(event -> shoppingList.addNewItem());
        // button menu prompt allowing the user to text a value by the first letter than print it out
        // into the terminal
        JMenuItem addFilterItem = new JMenuItem("Print Filter");
        addFilterItem.addActionListener(event -> shoppingList.FilterList());

        JMenuItem reloadFilter = new JMenuItem("Reload Text Filter");
        reloadFilter.addActionListener(event -> refil(shoppingList));

        // method addtions for file menu

        // closeItem: closes the window
        fileMenu.add(closeItem);
        fileMenu.add(newList);

        // method additions for edit menue
        editMenu.add(clearSelectedItem);
        editMenu.add(clearPurchasesItem);
        editMenu.add(addNewListItem);
        editMenu.add(addFilterItem);
        editMenu.add(reloadFilter);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        


        // returns the menubar with all it's functionality
        return menuBar;
    }
    
}


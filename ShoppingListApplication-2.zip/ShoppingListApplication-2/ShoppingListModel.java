import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

// /*
//  * Author: Prof Autorino
//  * 
//  * ShoppingListModel.java (WIP)
//  * Creates a custom DefaultListModel for our ShoppingListApplication.
//  * 
//  * https://docs.oracle.com/javase/8/docs/api/javax/swing/DefaultListModel.html
//  * 
//  * TODO: Complete class signature
//  */ 

// peduo code: the shopping listmodel makes the model
// the list holds methods like the panels

public class ShoppingListModel extends DefaultListModel<String> {
        // TODO: Use Dictionary of Labels and Booleans instead of ArrayList.
        // the jlabel is the key
        // the the jlabel has a boolean as a value
        private Dictionary<JLabel,Boolean> purchasedItems = new Hashtable<>();
        private final DefaultListModel<String> itemModel;
        //private List<Boolean> purchasedItems = new ArrayList<>();
            
        // taken from shopping list, 
        ShoppingListModel(String... purchasedItemList) {
            super();
            String[] tempStrings = purchasedItemList;
            this.itemModel = (DefaultListModel<String>) getModel();
            //this.purchasedItems = purchasedItemList;
            // copied from shopping list
            // adds the values of purchaseditems, to the model

            for(String item: purchasedItemList){
                addModelItem(item);
            }
            
            // TODO: Complete constructor

            //AddMouseListner: checks the position of the mouse
            // when the use clicks button 1; which is left click
            // addMouseListener(new MouseAdapter() {
            //     @Override 
            //     public void mouseClicked(MouseEvent mouseEvent) {
            //     if (mouseEvent.getButton() == MouseEvent.BUTTON1) {
            //         toggleItemAt(mouseEvent.getPoint());
            //         }
            //     }
            // });

            // actionMap: checks what actions and what to do when a button is pressed
        
            // toggles the item selected through the method 
        
            // getActionMap().put("togglePurchased", new AbstractAction() {
        
            //     @Override
        
            //     public void actionPerformed(ActionEvent event) {
        
            //         // toggle selected item as purchased
        
            //         toggleSelectedItem();
        
            //     } 
        
            // });


            

        }

        

        // TODO: Complete ShoppingListModel

        private DefaultListModel<String> getModel() {
            // TODO Auto-generated method stub
            throw new UnsupportedOperationException("Unimplemented method 'getModel'");
        }



        //AddItem: uses the parameter to add a string directly to the model
        //https://www.geeksforgeeks.org/java/dictionary-put-method-in-java-with-examples/
        public void addModelItem(String item) {
            JLabel tempLabel = new JLabel(item);
            purchasedItems.put(tempLabel,false);
            //purchasedItems.addElement(item,false);
            //purchasedItems.add(false);
        }

        
    // code took inspiration from link: https://www.youtube.com/watch?v=HbxccWk4VuQ
    public void FilterList(){
        List<String> result = new ArrayList<>();
        String Filtername = JOptionPane.showInputDialog("Type a letter to filter");
        char c = Filtername.charAt(0);

        for(String str: getItems()){
            if(str.charAt(0) == c ){
                result.add(str);

            }
        }
        for(int i = 0; i < result.size();i++){
            System.out.println(result.get(i));

        }
       

    }

    // //AddItem: uses the parameter to add a string directly to the model
    // public void addItem(String item) {
    //     itemModel.addElement(item);

    //     purchasedItems.add(false);
    // }

    // //ClearItems: clears the model information
    // public void clearItems() {
    //     itemModel.clear();
    //     purchasedItems.clear();
    // }

    // //RemoveSelectedItem: remove only the item highlighted by clicking on a model view
    // public void removeSelectedItem() {
    //     int index = getSelectedIndex();
    //     if (index >= 0) {
    //         itemModel.remove(index);
    //         purchasedItems.remove(index);
    //     }
    // }

    // RemovePurchasedItems(): Finds all the values with a boolean true/strikethoguh
    public void removePurchasedItems() {
        for (int index = purchasedItems.size() - 1; index >= 0; index--) {
            if (purchasedItems.get(index)) {
                itemModel.remove(index);
                purchasedItems.remove(index);
            }
        }
    }

    /**
     * Returns the current item text in display order.
     * 
     * @return List<String> items
     */
    public List<String> getItems() {
        List<String> items = new ArrayList<>(itemModel.size());
        for (int index = 0; index < itemModel.size(); index++) {
            items.add(itemModel.get(index));
        }
        return items;
    } 

    // toggleSelectedItem: based on the mouse position, selects the index of where the text is found
    // after all, it highlights the text, not strikethorugh. 
    private void toggleSelectedItem() {
        int index = getSelectedIndex();
        if (index >= 0) {
            togglePurchased(index);
        }
    }

    //TogglePurchased: use the index to see the position of where the text is
    // than make a strikethoguh effect by repainting the text.
    private void togglePurchased(int index) {
        purchasedItems.set(index, !purchasedItems.get(index));
        repaint(getCellBounds(index, index));
    }

    //toggleItemAt: uses the point parameter to see where the user cusuro is. Depending on the hitbox of the 
    //cursor and the hitbox of the text. it can select the listed item and make a strik throug
    private void toggleItemAt(Point point) {
        int index = locationToIndex(point);
        if (index >= 0 && getCellBounds(index, index).contains(point)) {
            setSelectedIndex(index);
            togglePurchased(index);
        }
    }

    
    // start line: for button methods found in edit menu

    // Clear Selection: removes the line of text, the user has selected
    // calls remove sected item
    public void clearSelection(){
        removeSelectedItem();
    }

    // clears all crossed out purchases the user has
    // uses the removepurchaseditems methods
    public void clearPurchases(){
        removePurchasedItems();

    }

    //addNewItem: asks the user for the name of the new item. than by using addItem, it's added to the list
    public void addNewItem(){
        // Joption pane: gives a prompt for the user to answer, and than it turns into a string
        // than it's added to the model.
        String NewItem = JOptionPane.showInputDialog("Type New Item");
        addItem(NewItem);
        

    }

    // A method for the user to update the filter section, by resetting it.
    public void updatefilter(FilteredJList list){
        for (String item : getItems()) {
                list.addItem(item);

        }
        //list.refilter();
    }

    //end of methods used for edit menu

    // start of methods for file menu

    // MakeNewList: removes the current list, and allow the user to make a new list
    // 
    // clears everything on the list
    public void makeNewList(){
        clearItems();

    }

        

        
}
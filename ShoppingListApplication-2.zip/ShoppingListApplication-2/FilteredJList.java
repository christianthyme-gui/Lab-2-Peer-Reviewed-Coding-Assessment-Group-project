// swing hack 13
//filtered list
import java.util.ArrayList;


import javax.swing.AbstractListModel;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

// FilteredJlist: a class design to allow the user to type and than filter information for the user on the go
@SuppressWarnings("rawtypes")
public class FilteredJList extends JList<String> {
    

    private FilterField filterField;

    private int DEFAULT_FIELD_WIDTH = 20;

    public FilteredJList() {

        super( );

        setModel (new FilterModel( ));

        filterField = new FilterField (DEFAULT_FIELD_WIDTH);

    }

    @SuppressWarnings("unchecked")
    public void setModel (ListModel m) {

        if (! (m instanceof FilterModel))

            throw new IllegalArgumentException( );

            super.setModel (m);

        }


        //AddItem:Addes the object to the model: which in this case is a string.
        public void addItem (Object o) {

            ((FilterModel)getModel( )).addElement (o);

        }

        //Clear: a custom method used to remove all the information from the model
        public void clear() {

            ((FilterModel)getModel( )).clear();

        }

        //getFilterField: returns the filterfield; which is what's used for the user to type.
        public JTextField getFilterField( ) {

            return filterField;

        }

        class FilterModel extends AbstractListModel {

            ArrayList items;

            ArrayList filterItems;

            public FilterModel( ) {

                super( );

                items = new ArrayList();

                filterItems = new ArrayList( );

            }

            public Object getElementAt (int index) {

                if (index < filterItems.size( ))

                    return filterItems.get (index);

                    else

                        return null;

                    }

                    public int getSize( ) {

                        return filterItems.size( );

                    }

                    @SuppressWarnings("unchecked")
                    public void addElement (Object o) {

                        items.add (o);

                        refilter( );

                    }

                    public void removeElement (Object o) {

                        items.remove(o);

                        refilter( );

                    }

                    public void clear() {
                        filterItems.clear();

                        items.clear();

                        refilter( );

                    }

                    // attempt to make structure that updates the filter

                    public void refilter(ShoppingList list){
                       items.clear( );
                       for (String item : list.getItems()) {
                            list.addItem(item);



                       }   

                    }

                    @SuppressWarnings("unchecked")
                    public void refilter( ) {

                        filterItems.clear();
                        //ShoppingList slist = new ShoppingList("ShoppingList","");
                        //String term = getFilterField().list.getItems();

                        String term = getFilterField().getText();
                        //ShoppingList list = new ShoppingList("list ex", "jelly","ham");
                        //String term = getFilterField().getText( );

                        for (int i=0; i<items.size( ); i++)


                            if (items.get(i).toString( ).indexOf(term, 0) != -1)
                                
                                //updatefilter(FilteredJList list)

                                filterItems.add (items.get(i));

                                fireContentsChanged (this, 0, getSize( ));

                            }

                        }

                        // FilterField inner class listed below
                        // inner class provides filter-by-keystroke field

                        class FilterField extends JTextField implements DocumentListener {

                            public FilterField (int width) {

                                super(width);

                                getDocument().addDocumentListener (this);

                            }

                            public void changedUpdate (DocumentEvent e) {

                                ((FilterModel)getModel()).refilter( );

                            }

                            public void insertUpdate (DocumentEvent e) {


                                ((FilterModel)getModel()).refilter( );

                            }

                            public void removeUpdate (DocumentEvent e) {

                                ((FilterModel)getModel()).refilter( );

                            }

                        }


                    }
                




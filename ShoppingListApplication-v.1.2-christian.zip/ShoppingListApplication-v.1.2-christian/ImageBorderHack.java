
// is from swing hack 3,
// a tester for the imageborder hack
import javax.swing.*;

public class ImageBorderHack {
public static void main(String[] args) {
JFrame frame = new JFrame("Hack #3: Fill Your Borders with Pretty Pictures");
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
JPanel panel = new JPanel( );
JButton button = new JButton("Image Border Test");
panel.add(button);
ImageBorder image_border = new ImageBorder(
new ImageIcon("images/BorderFrames/upper_left.png").getImage( ),
new ImageIcon("images/BorderFrames/upper.png").getImage( ),
new ImageIcon("images/BorderFrames/upper_right.png").getImage( ),
new ImageIcon("images/BorderFrames/left_center.png").getImage( ),
new ImageIcon("images/BorderFrames/right_center.png").getImage( ),
new ImageIcon("images/BorderFrames/bottom_left.png").getImage( ),
new ImageIcon("images/BorderFrames/bottom_center.png").getImage( ),
new ImageIcon("images/BorderFrames/bottom_right.png").getImage( )
);
panel.setBorder(image_border);
frame.getContentPane( ).add(panel);
frame.pack( );
frame.setVisible(true);
}
}
//// // is from swing hacks 2
// // contribution down below
// //“Swing Hacks /by Joshua Marinacci and Chris Adamson. Copyright 2005 O’Reilly Media,
// //Inc., 0-596-00907-0.”

// gets the java directories for the variables like color to work correctly.

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JLabel;

public class RichJLabel extends JLabel {

    private int tracking;


    public RichJLabel(String text, int tracking) {

    super(text);

    this.tracking = tracking;
}

private int left_x, left_y, right_x, right_y;
private Color left_color, right_color;

// ads a offset for the left color
public void setLeftShadow(int x, int y, Color color) {

    left_x = x;

    left_y = y;

    left_color = color;
}

// adds a offset for the right color
public void setRightShadow(int x, int y, Color color) {

    right_x = x;

    right_y = y;

    right_color = color;
}

// gets the font size used from the information passed by DropShadow java
public Dimension getPreferredSize( ) {

    String text = getText( );

    FontMetrics fm = this.getFontMetrics(getFont( ));

    int w = fm.stringWidth(text);

    w += (text.length( )-1)*tracking;

    w += left_x + right_x;

    int h = fm.getHeight( );

    h += left_y + right_y;

    return new Dimension(w,h);
}
// antalize and smooths out the text drawn to the screen.
public void paintComponent(Graphics g) {

    ((Graphics2D)g).setRenderingHint(

        RenderingHints.KEY_TEXT_ANTIALIASING,

        RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        char[] chars = getText().toCharArray( );

        FontMetrics fm = this.getFontMetrics(getFont( ));

        int h = fm.getAscent( );

        int x = 0;

        for(int i=0; i<chars.length; i++) {

            char ch = chars[i];

            int w = fm.charWidth(ch) + tracking;

            g.setColor(left_color);

            g.drawString(""+chars[i],x-left_x,h-left_y);

            g.setColor(right_color);

            g.drawString(""+chars[i],x+right_x,h+right_y);

            g.setColor(getForeground( ));

            g.drawString(""+chars[i],x,h);

            x+=w;

        }

        ((Graphics2D)g).setRenderingHint(

            RenderingHints.KEY_TEXT_ANTIALIASING,

            RenderingHints.VALUE_TEXT_ANTIALIAS_DEFAULT);

        }

    } // end paintComponent( )
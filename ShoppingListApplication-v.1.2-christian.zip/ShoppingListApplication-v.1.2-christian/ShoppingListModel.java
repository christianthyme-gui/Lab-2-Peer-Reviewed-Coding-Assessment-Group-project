
import java.util.HashMap;

import java.util.Map;

import javax.swing.DefaultListModel;


/*
Base on the model autronino gave in moodle
 * Author: Prof Autorino
 * 
 * ShoppingListModel.java (WIP)
 * Creates a custom DefaultListModel for our ShoppingListApplication.
 * 
 * https://docs.oracle.com/javase/8/docs/api/javax/swing/DefaultListModel.html
 * 
 * 
 * Theshoppinglist, adds methods from the shoppingList, and add custom version of the methodd used 
 * by the default list model
 */ 

//for the model, i think overcomplicated the idea by adding renderer and methods
// for this model, it replaces the orignal default list model methods.
public class ShoppingListModel extends DefaultListModel<String> {
        // -Completed Use Dictionary of Labels and Booleans instead of ArrayList.
        // used maps instead of dictionaries at the professor request

        // learned about maps that allows 
        // used dictionaries as that what the assignment calls for
        // use the put method command to add both a key and value
        //String is the key, Boolean is the value
        //https://www.baeldung.com/java-hashmap-vs-dictionary
        //private final Dictionary<String,Boolean> purchasedItems = new Hashtable<>();
        private final Map<String,Boolean> purchasedItems = new HashMap<>();

        //private List<Boolean> purchasedItems = new ArrayList<>();

        // ShoppingListModel(List<Boolean> purchasedItemList) {
        //     this.purchasedItems = purchasedItemList;

        //     // TODO: Complete constructor

        // }
        // TODO: Complete ShoppingListModel
        // adds the based methods that are used from the shopping list
        /* 
        AddModelItem: adds a item, and sets it false
        ClearModelItems: Clears the model used
        removeModelItemAt(int index): removes the index that stores both the key and value found in the dictionary
        
        */

         // add places both the string and boolean false to the dictoonaty
         // a custom version the add method from defaultlistModel
        public void add(String Item){
            purchasedItems.put(Item,false);
        }

        @Override
        //Clear: removes all the elemenets found in the dictionary
        public void clear() {
            //purchasedItems.removeAllElements();
            super.clear();
            //purchasedItems.clear();
            //purchasedItems.clear();
        
        }

       // is taken from the shoppinglist
       // used to return the element of value and key found at the index. 
        public boolean isPurchasedAtModel(int index){
            return purchasedItems.get(getElementAt(index));
        }

        // is based on remove
        // used to remove the value and key at the number index of the dictionary
        public void removeModelItemAt(int index){
            purchasedItems.remove(index);
        }

        // return all the elements of purchaseditem dictionary as a 
        public String tostring(){
            return purchasedItems.toString();
        }

        // returns the size of the dictonary
        public int size(){
            return purchasedItems.size();
        }

        

        
}

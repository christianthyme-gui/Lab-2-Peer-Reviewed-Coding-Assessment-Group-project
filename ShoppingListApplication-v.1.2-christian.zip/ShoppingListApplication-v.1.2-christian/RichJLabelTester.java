//// // is from swing hacks 2
// // contribution down below
// //“Swing Hacks /by Joshua Marinacci and Chris Adamson. Copyright 2005 O’Reilly Media,
// //Inc., 0-596-00907-0.”
// acts as a tester for RichLabel java file
// not attached to the main program

import javax.swing.JFrame;
import java.awt.Color;

public class RichJLabelTester {

    public static void main(String[] args) {

        RichJLabel label = new RichJLabel("76", -40);

        // drop shadow w/ highlight

        label.setLeftShadow(1,1,Color.blue);

        label.setRightShadow(2,3,Color.green);

        label.setForeground(Color.yellow);

        label.setFont(label.getFont( ).deriveFont(140f));

        JFrame frame = new JFrame("RichJLabel hack");

        frame.getContentPane( ).add(label);

        frame.pack( );

        frame.setVisible(true);

    }
    
}

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.TextAttribute;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.Point;
import java.awt.Component;
import java.awt.Font;

//Todo: make the textfilter text insenitive

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.AbstractAction;
import javax.swing.DefaultListCellRenderer;
import javax.swing.ImageIcon;

/**
 * 
 * ShoppingList
 * A string-based shopping list component with toggleable purchased items and a title header. 
 */
// uses the shoppinglistmodel to replace defaultlist model for the 
public class ShoppingList extends JList<String> {
    
    // uses ShoppingListmodel for it methods, 
    // instead of the normal default listmodel
    private final ShoppingListModel itemModel;
        //private final DefaultListModel<String> itemModel;

    private final List<Boolean> purchasedItems = new ArrayList<>();
    
    //filter variables that search all items, index and create a new field for array.
    private final List<String> allItems = new ArrayList<>(); 
    private final List<Integer> indexes = new ArrayList<>();
    private final JTextField filterField = new JTextField(20);

    // RichJ Label_Swing hack 2: changes how the text is displayed, adding variation
    private RichJLabel headerLabel;
    public JPanel header;

    /**
    *
    * Creates a shopping list with the given title and initial items
    *  
    * @param title text shown in the list's column header.
    * @param initialItems items to displau initially; may be blank 
    * 
    * new ShoppingList("Title", "Milk", "Eggs", "Cheese")
    */
    public ShoppingList(String title, String... initialItems) {
        //super(new DefaultListModel<>());
        super(new ShoppingListModel());
        this.itemModel = (ShoppingListModel) getModel();
        //FilteredJList list = new FilteredJList( );
        //this.itemModel = (DefaultListModel<String>) getModel();        
        // uses swinghack 2 to change header, allowing it to be more easier differentiated from the body text
        this.headerLabel = new RichJLabel(title,10);

        headerLabel.setForeground(Color.ORANGE);

        headerLabel.setFont(headerLabel.getFont( ).deriveFont(14f));
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setCellRenderer(new ShoppingListItemRenderer());

        // prints out the list of items from the parameter value initial items.
        for (String item : initialItems) {
            addItem(item);
            
        }

        //AddMouseListner: checks the position of the mouse
        // when the use clicks button 1; which is left click
        addMouseListener(new MouseAdapter() {
            @Override 
            public void mouseClicked(MouseEvent mouseEvent) {
                if (mouseEvent.getButton() == MouseEvent.BUTTON1) {
                    toggleItemAt(mouseEvent.getPoint());
                }
            }
        });

        // actionMap: checks what actions and what to do when a button is pressed
        // toggles the item selected through the method 
        getActionMap().put("togglePurchased", new AbstractAction() {
           @Override
           public void actionPerformed(ActionEvent event) {
              // toggle selected item as purchased
              toggleSelectedItem();
           } 
        });
        //document listener from swing hack #13
        filterField.getDocument().addDocumentListener(
            new DocumentListener() {

                @Override 
                public void insertUpdate(DocumentEvent e) {
                    refilter();
                }

                @Override 
                public void removeUpdate(DocumentEvent e) {
                    refilter();
                }

                @Override
                public void changedUpdate(DocumentEvent e) {
                    refilter();
                }
        });
    }

    /**
     * Creates a scroll pane with this list and its title header.
     * 
     * @return JScrollPane scrollPane
     */
    public JScrollPane createScrollPane() {
        // Is from Swing hack 2- Image border
        ImageBorder image_border = new ImageBorder(
                new ImageIcon("images/BorderFrames/upper_left.png").getImage( ),
                new ImageIcon("images/BorderFrames/upper.png").getImage( ),
                new ImageIcon("images/BorderFrames/upper_right.png").getImage( ),
                new ImageIcon("images/BorderFrames/left_center.png").getImage( ),
                new ImageIcon("images/BorderFrames/right_center.png").getImage( ),
                new ImageIcon("images/BorderFrames/bottom_left.png").getImage( ),
                new ImageIcon("images/BorderFrames/bottom_center.png").getImage( ),
                new ImageIcon("images/BorderFrames/bottom_right.png").getImage( )
                );
                
        JScrollPane scrollPane = new JScrollPane(this);
        JPanel header = new JPanel(new BorderLayout());
        header.setBorder(image_border);
        header.add(headerLabel, BorderLayout.NORTH);
        header.add(filterField, BorderLayout.CENTER);
        scrollPane.setColumnHeaderView(header);
        return scrollPane;
    }

    // // code took inspiration from link: https://www.youtube.com/watch?v=HbxccWk4VuQ
    // public void FilterList(){
    //     List<String> result = new ArrayList<>();
    //     String Filtername = JOptionPane.showInputDialog("Type a letter to filter");
    //     char c = Filtername.charAt(0);

    //     for(String str: getItems()){
    //         if(str.charAt(0) == c ){
    //             result.add(str);

    //         }
    //     }
    //     for(int i = 0; i < result.size();i++){
    //         System.out.println(result.get(i));

    //     }
       

    // }
    /**
     * update the item based on the filter text
     * item that doesn't match are hidden
     */
    private void refilter() { 
        String term = filterField.getText();

        itemModel.clear();
        indexes.clear();

        for (int index = 0; index < allItems.size(); index++) {
            if (allItems.get(index).indexOf(term, 0) != -1) {
                itemModel.addElement(allItems.get(index));
                indexes.add(index);
            }
        }
    }

    //AddItem: uses the parameter to add a string directly to the model
    public void addItem(String item) {
        itemModel.addElement(item);
        allItems.add(item);
        purchasedItems.add(false);
        refilter();
    }

    //ClearItems: clears the model information
    public void clearItems() {
        allItems.clear();
        itemModel.clear();
        purchasedItems.clear();
        refilter();
    }

    //RemoveSelectedItem: remove only the item highlighted by clicking on a model view
    public void removeSelectedItem() {
        int index = getSelectedIndex();
        if (index >= 0) {
            int originalIndex = indexes.get(index);
            
            allItems.remove(originalIndex);
            purchasedItems.remove(originalIndex);
            refilter();
            //itemModel.remove(index);
            //purchasedItems.remove(index);
        }
    }

    // RemovePurchasedItems(): Finds all the values with a boolean true/strikethoguh
    public void removePurchasedItems() {
        for (int index = purchasedItems.size() - 1; index >= 0; index--) {
            if (purchasedItems.get(index)) {
                allItems.remove(index);
                // uses custom version found in the shoppinglist model
                itemModel.removeModelItemAt(index);
                purchasedItems.remove(index);
            }
        }
        refilter();
    }

    /**
     * Returns the current item text in display order.
     * Changed: this is snippet i got help by aung, which 
     * now since we got the allitems array storing everything
     * it can be returned since it a temp array.
     * @return List<String> items
     */
    public List<String> getItems() {
        // List<String> items = new ArrayList<>(itemModel.size());
        // for (int index = 0; index < itemModel.size(); index++) {
        //     items.add(itemModel.get(index));
        // }
        // return items;
        return new ArrayList<>(allItems);
    } 

    // toggleSelectedItem: based on the mouse position, selects the index of where the text is found
    // after all, it highlights the text, not strikethorugh. 
    private void toggleSelectedItem() {
        int index = getSelectedIndex();
        if (index >= 0) {
            togglePurchased(index);
        }
        refilter();
    }

    //TogglePurchased: use the index to see the position of where the text is
    // than make a strikethoguh effect by repainting the text.
    private void togglePurchased(int index) {
        purchasedItems.set(index, !purchasedItems.get(index));
        repaint(getCellBounds(index, index));
        
    }

    //toggleItemAt: uses the point parameter to see where the user cusuro is. Depending on the hitbox of the 
    //cursor and the hitbox of the text. it can select the listed item and make a strik throug
    private void toggleItemAt(Point point) {
        int index = locationToIndex(point);
        if (index >= 0 && getCellBounds(index, index).contains(point)) {
            setSelectedIndex(index);
            togglePurchased(index);
        }
        
    }

    
    // start line: for button methods found in edit menu

    // Clear Selection: removes the line of text, the user has selected
    // calls remove sected item
    public void clearSelection(){
        removeSelectedItem();
        refilter();
    }

    // clears all crossed out purchases the user has
    // uses the removepurchaseditems methods
    public void clearPurchases(){
        removePurchasedItems();
        refilter();

    }

    //addNewItem: asks the user for the name of the new item. than by using addItem, it's added to the list
    public void addNewItem(){
        // Joption pane: gives a prompt for the user to answer, and than it turns into a string
        // than it's added to the model.
        String NewItem = JOptionPane.showInputDialog("Type New Item");
        addItem(NewItem);
        refilter();
        
    }

    // A method for the user to update the filter section, by resetting it.
    // public void updatefilter(FilteredJList list){
    //     for (String item : getItems()) {
    //             list.addItem(item);

    //     }
    //     //list.refilter();
    // }

    //end of methods used for edit menu

    // start of methods for file menu

    // MakeNewList: removes the current list, and allow the user to make a new list
    // 
    // clears everything on the list
    public void makeNewList(){
        clearItems();
        refilter();

    }
    //
    
    

    //


    /**
    * ShoppingListItemRenderer overrides the default rendering behavior of list items so that
    * the app can modify text attributes of purchased rows to reflect the purchasedItems list.
    * We must use a HashMap to modify the font of a component in a ListCellRenderer.
    * 
    */
    private final class ShoppingListItemRenderer extends DefaultListCellRenderer {
        @Override 
        public Component getListCellRendererComponent(JList<?> list,
                                              Object value,
                                              int index,
                                              boolean isSelected,
                                              boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            setText(value == null ? "" : value.toString());
            if (index >= 0 && index < purchasedItems.size() && purchasedItems.get(index)) {
                Map<TextAttribute, Object> attributes = new HashMap<>();
                attributes.put(TextAttribute.STRIKETHROUGH, TextAttribute.STRIKETHROUGH_ON);
                Font font = getFont();
                setFont(font.deriveFont(attributes));
            }
            return this;                                 
        }
    }
}


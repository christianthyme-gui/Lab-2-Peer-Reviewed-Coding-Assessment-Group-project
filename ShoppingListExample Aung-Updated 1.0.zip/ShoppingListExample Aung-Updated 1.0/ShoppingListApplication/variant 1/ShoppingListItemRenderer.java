// import java.util.HashMap;
// import java.util.Map;

// import javax.swing.DefaultListCellRenderer;
// import javax.swing.JList;

// // public ShoppingListItemRenderer extends DefaultListCellRenderer{
// //     public final class ShoppingListItemRenderer() {
// //         @Override 
// //         public Component getListCellRendererComponent(JList<?> list,
// //                                               Object value,
// //                                               int index,
// //                                               boolean isSelected,
// //                                               boolean cellHasFocus) {
// //             super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
// //             setText(value == null ? "" : value.toString());
// //             if (index >= 0 && index < purchasedItems.size() && purchasedItems.get(index)) {
// //                 Map<TextAttribute, Object> attributes = new HashMap<>();
// //                 attributes.put(TextAttribute.STRIKETHROUGH, TextAttribute.STRIKETHROUGH_ON);
// //                 Font font = getFont();
// //                 setFont(font.deriveFont(attributes));
// //             }
// //             return this;                                 
// //         }
// //     }



// // }
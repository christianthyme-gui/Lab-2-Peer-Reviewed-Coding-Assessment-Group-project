// package bac;
// import java.util.ArrayList;
// import java.util.Dictionary;
// import java.util.Hashtable;
// import java.util.List;

// import javax.swing.AbstractAction;
// import javax.swing.DefaultListModel;
// import javax.swing.JLabel;
// import javax.swing.JTextField;
// import javax.swing.ListSelectionModel;
// import javax.swing.event.DocumentListener;

// import org.w3c.dom.events.MouseEvent;

// /*
//  * Author: Prof Autorino
//  * 
//  * ShoppingListModel.java (WIP)
//  * Creates a custom DefaultListModel for our ShoppingListApplication.
//  * 
//  * https://docs.oracle.com/javase/8/docs/api/javax/swing/DefaultListModel.html
//  * 
//  * TODO: Complete class signature
//  */ 
// public class ShoppingListModel extends DefaultListModel<String> {
//         // TODO: Use Dictionary of Labels and Booleans instead of ArrayList.
//         private final Dictionary<String,Boolean> purchasedItems = new Hashtable<>();
//         private final DefaultListModel<String> itemModel;
    
    
    
//         //filter variables that search all items, index and create a new field for array.
    
//         private final List<String> allItems = new ArrayList<>(); 
    
//         private final List<Integer> indexes = new ArrayList<>();
    
//         private final JTextField filterField = new JTextField(20);

//         //adds every value into the dictionary using the method add ModelItem
//         ShoppingListModel(String...purchasedItemList) {
//             //this.purchasedItems = purchasedItemList;
//             super(new DefaultListModel<>());
        
//             this.itemModel = (DefaultListModel<String>) getModel();
        
        
//             setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
//             setCellRenderer(new ShoppingListItemRenderer());
            

//             // TODO: Complete constructor
//             // taken from the shopping list methods,
//             // changed names to ma
//             for(String item: purchasedItemList){
//                 addModelItem(item);
//             }
//             // addMouseListener(new MouseAdapter() {
//             //     @Override 
//             //     public void mouseClicked(MouseEvent mouseEvent) {
//             //         if (mouseEvent.getButton() == MouseEvent.BUTTON1) {
//             //             toggleItemAt(mouseEvent.getPoint());
//             //         }
//             //     }
//             // });
//             // getActionMap().put("togglePurchased", new AbstractAction() {
//             //     @Override
//             //     public void actionPerformed(ActionEvent event) {
//             //         // toggle selected item as purchased
//             //         toggleSelectedItem();
//             //     } 
//             // });
//             // //document listener from swing hack #13
//             // filterField.getDocument().addDocumentListener(
//             // new DocumentListener() {

//             //     @Override 
//             //     public void insertUpdate(DocumentEvent e) {
//             //         refilter();
//             //     }

//             //     @Override 
//             //     public void removeUpdate(DocumentEvent e) {
//             //         refilter();
//             //     }

//             //     @Override
//             //     public void changedUpdate(DocumentEvent e) {
//             //         refilter();
//             //     }
//             // });


//         }

//         // TODO: Complete ShoppingListModel
//         /**
     
//         * update the item based on the filter text
     
//         * item that doesn't match are hidden
     
//         */
    
//         private void refilter() { 
        
//             String term = filterField.getText();

        
//             itemModel.clear();
        
//             indexes.clear();

        
//             for (int index = 0; index < allItems.size(); index++) {
        
//                 if (allItems.get(index).indexOf(term, 0) != -1) {
        
//                     itemModel.addElement(allItems.get(index));
        
//                     indexes.add(index);
        
//                 }
        
//             }
    
//         }

//         public void addModelItem(String purchasedItemList) {
//             purchasedItems.put(purchasedItemList,false);
//             // allItems.add(purchasedItemList);
//             // purchasedItems.add(false);
//             // refilter();
    
//         }

//         // copied 
//         public void removeSelectedModelItem(){
//             int index = getSelectedIndex();
//             if (index >= 0){
//                 int originalIndex = indexes.get(index);
//                 allItems.remove(originalIndex);
//                 purchasedItems.remove(originalIndex);
//                 refilter();

//             }
//         }

//         /**
//      * remove all items that have been marked as purchase
//      * loop backwards to prevent index from shifting when removing item
//      */
//     public void removePurchasedModelItems() {
//         for (int index = purchasedItems.size() - 1; index >= 0; index--) {
//             if (purchasedItems.get(index)) {
//                 allItems.remove(index);
//                 purchasedItems.remove(index);
//             }
//         }
//         refilter();
//     }
//     /**
//      * Returns the current item text in display order.
//      * 
//      * @return List<String> items
//      */
//     public List<String> getModelItems() {
//         return new ArrayList<>(allItems);
//     } 

//     /**
//      * toggles the selected item to mark if have been purchase or not
//      * get the index of the item and call teh togglepurchase
//      */
//     private void toggleSelectedItem() {
//         int index = getSelectedModelIndex();
//         if (index >= 0) {
//             togglePurchased(index);
//         }
//     }

//     /**
//      * toggle the purchase status of an item
//      * uses original index since filtering change positions
//      * @param index
//      */
//     private void togglePurchased(int index) {
//         int originalIndex = indexes.get(index);

//         purchasedItems.set(originalIndex, !purchasedItems.get(originalIndex));
//         repaint(getCellBounds(index, index));
//     }



        
// }

import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultListModel;
// made complelety with ai, don't use it for submission,
// works but prefer it to be more human made
public class aiShoppingListmodel extends DefaultListModel<String> {
    private final Map<String, Boolean> purchasedItems = new HashMap<>();

    public void addItem(String item) {
        super.addElement(item);
        purchasedItems.putIfAbsent(item, false);
    }

    public void togglePurchasedAt(int index) {
        if (index >= 0 && index < getSize()) {
            String item = getElementAt(index);
            boolean currentlyPurchased =
                    Boolean.TRUE.equals(purchasedItems.get(item));

            purchasedItems.put(item, !currentlyPurchased);
        }
    }

    public boolean isPurchasedAt(int index) {
        if (index < 0 || index >= getSize()) {
            return false;
        }

        return Boolean.TRUE.equals(purchasedItems.get(getElementAt(index)));
    }

    public void removeItemAt(int index) {
        if (index >= 0 && index < getSize()) {
            String removedItem = getElementAt(index);
            super.removeElementAt(index);

            // Keep the dictionary entry if another item has the same name.
            if (!contains(removedItem)) {
                purchasedItems.remove(removedItem);
            }
        }
    }

    public void clearItems() {
        super.clear();
        purchasedItems.clear();
    }

    private boolean contains(String item) {
        for (int i = 0; i < getSize(); i++) {
            if (getElementAt(i).equals(item)) {
                return true;
            }
        }
        return false;
    }
}

